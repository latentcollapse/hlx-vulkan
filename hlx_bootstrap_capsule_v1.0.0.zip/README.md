# HLX Bootstrap Capsule (HBC) v1.0.0

This package contains the complete, self-contained definition of the HLX Language Family (Transport Layer).
Upload this entire folder (or zip) to an LLM to bootstrap it with HLX capabilities.

## Contents

* **SYSTEM_PROMPT.txt**: The primary directive for LLM alignment.
* **hlx_grammar.ebnf**: Formal grammar for HLX/HLXL surface syntax.
* **hlx_codex.json**: The formal specification (Grammar, Semantics, Values).
* **hlx_contracts.json**: Structural contract registry (Primitives + Allowed Unknowns).
* **hlx_runtime_conformance.json**: The rules of the runtime engine and error taxonomy.
* **hlx_triggers.yaml**: Canonical mode switches (HPCP).
* **hlx_examples.hlx(l)**: Rosetta stone examples.
* **lc12_manifest_schema.json**: LC_12 Transfer Envelope v0.2-frozen schema.
* **hlx_terminology_canon.json**: Normative terminology definitions.

## Version Binding & Scope

* **Capsule Version:** v1.0.0
* **Architecture Class:** TRANSPORT (No execution semantics)
* **Conformance:** Bound. Mismatched versions are non-conformant.

## HLX Literacy Self-Test

To verify HLX literacy, a model should be able to:

1. **Transliterate:** Convert the following HLX to HLXL:
   ```hlx
   ⟠ test { ◇ main() { ⊢ x = {14:{@0:42}}; ↩ x; } }
   ```

2. **Lower:** Produce HLX-Lite value for `{14:{@0:42}}`

3. **Encode LC-B:** Emit hex bytes for integer `123`
   Expected: `01 7B`

4. **Validate:** Identify the error in `🜊 14 🜂`
   Expected: `E_LC_PARSE` (illegal whitespace)

5. **Construct LC_12 Manifest:** Given a 7-byte payload, produce manifest skeleton.

A model that completes all 5 tasks is HLX-literate.

## Density Profiles (Optional)

HLX v1.0.0 includes an optional density profile for surface syntax shorthand.

- Density rules are **DISPLAY-ONLY** and do not affect LC-B encoding.
- All density forms expand to canonical HLX/HLXL before lowering.
- LC-B remains the authoritative format for hashing and transport.
- Tooling MAY implement density expansion but is not required for conformance.

See `hlx_density_profile.json` for rules.

## LC_12 Transfer Envelope v0.2-frozen

### Merkle Tree
MERKLE SPEC (FANOUT 16, CANONICAL):

Let chunks be ordered by index i = 0..N-1.

Leaf hash: H_leaf[i] = BLAKE3(chunk_bytes[i]).

Group leaves in order into nodes of up to 16 children.

INTERNAL NODE (CANONICAL):

- Let child_count be the number of children in this node, where 1 ≤ child_count ≤ 16.
- Let child_hashes be the ordered list of child hashes for this node.
- Compute the internal node hash as:

  H_node = BLAKE3(
    byte(child_count) ||
    concat(child_hash_0 || child_hash_1 || ... || child_hash_(child_count-1))
  )

- If child_count < 16, PAD with 32-byte zero hashes before hashing.
- child_hash_i MUST be the 32-byte BLAKE3 digest of the corresponding child.
- Children MUST be concatenated in strictly increasing child index order.
- Root hash = top node hash.

VERIFICATION RULE:
- A receiver MUST recompute leaf hashes, rebuild the tree using this exact rule,
  and compare the resulting payload_root to the manifest.
- Any mismatch is fatal (E_ENV_PAYLOAD_HASH_MISMATCH).

### Table Ordering
TABLE ORDER KEY (CANONICAL):

Normalize handle string with Unicode NFC.

Lowercase using Unicode simple case-folding.

Strip exactly one leading literal "&h_" prefix if present; strip nothing else.

order_key = UTF-8 bytes of resulting string.

Sort ascending lexicographic by order_key bytes.

- Case folding MUST use Unicode 15.0 simple case folding as defined in
  Unicode Character Database file CaseFolding.txt.
- Non-ASCII handles raise E_HANDLE_INVALID.

## Usage

1. Upload this zip to the LLM.
2. Tell the LLM: "Initialize from the HLX Bootstrap Capsule."
3. The LLM is now HLX-Native (Transport Only).

CAPSULE_INTEGRITY_HASH_SHA256: COMPUTE_WITH_EXPORTER